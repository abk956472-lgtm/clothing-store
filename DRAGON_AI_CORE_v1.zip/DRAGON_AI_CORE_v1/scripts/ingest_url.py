import argparse
from dragon_core.config import DB_PATH
from dragon_core.memory.store import Store
from dragon_core.internet.reader import fetch_url

p = argparse.ArgumentParser()
p.add_argument("url")
args = p.parse_args()

text = fetch_url(args.url)
store = Store(DB_PATH)
item_id = store.add_knowledge(
    text[:50000], source="url-ingestion", url=args.url,
    confidence=0.3, status="unverified"
)
print(f"stored knowledge id={item_id}, chars={min(len(text),50000)}")
