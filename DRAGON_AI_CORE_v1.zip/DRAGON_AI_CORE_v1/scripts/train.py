import argparse
from pathlib import Path
from dragon_core.learning.trainer import train_text

p = argparse.ArgumentParser()
p.add_argument("--data", default="data/train.txt")
p.add_argument("--epochs", type=int, default=3)
p.add_argument("--batch-size", type=int, default=8)
p.add_argument("--lr", type=float, default=3e-4)
args = p.parse_args()

train_text(Path(args.data), args.epochs, args.batch_size, args.lr)
