from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from ..config import DB_PATH, CHECKPOINT
from ..memory.store import Store
from ..rag.retriever import Retriever
from ..model.engine import ModelEngine
from ..internet.reader import fetch_url

app = FastAPI(title="DRAGON AI CORE", version="1.0.0")
store = Store(DB_PATH)
retriever = Retriever(store)
engine = ModelEngine(CHECKPOINT)

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=10000)
    use_memory: bool = True
    max_new_tokens: int = Field(default=160, ge=1, le=512)

class MemoryIn(BaseModel):
    content: str = Field(min_length=1, max_length=20000)
    kind: str = "user"

class KnowledgeIn(BaseModel):
    content: str = Field(min_length=1, max_length=50000)
    source: str = ""
    url: str = ""
    confidence: float = Field(default=0.5, ge=0, le=1)

class UrlIn(BaseModel):
    url: str

@app.get("/health")
def health():
    return {
        "status": "ok",
        "core": "DRAGON AI CORE v1",
        "checkpoint_exists": CHECKPOINT.exists(),
        "model_loaded": engine.loaded,
        "database": str(DB_PATH),
    }

@app.post("/memory")
def memory(body: MemoryIn):
    return {"id": store.add_memory(body.content, body.kind)}

@app.post("/knowledge")
def knowledge(body: KnowledgeIn):
    return {"id": store.add_knowledge(
        body.content, body.source, body.url, body.confidence
    )}

@app.post("/retrieve")
def retrieve(query: str, limit: int = 5):
    return {"results": retriever.search(query, limit)}

@app.post("/ingest-url")
def ingest_url(body: UrlIn):
    try:
        text = fetch_url(body.url)
        # Store a bounded amount in v1; future versions can chunk documents.
        content = text[:50000]
        item_id = store.add_knowledge(
            content, source="url-ingestion", url=body.url,
            confidence=0.3, status="unverified"
        )
        return {"id": item_id, "characters": len(content)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/chat")
def chat(body: ChatIn):
    try:
        context = retriever.build_context(body.message, 5) if body.use_memory else ""
        memories = store.recent_memories(8) if body.use_memory else []
        memory_text = "\n".join(m["content"] for m in memories)
        prompt = body.message
        if context:
            prompt = f"Knowledge context:\n{context}\n\nUser:\n{body.message}"
        if memory_text:
            prompt = f"Recent memory:\n{memory_text}\n\n{prompt}"
        answer = engine.generate(prompt, max_new_tokens=body.max_new_tokens)
        store.add_memory(f"USER: {body.message}\nDRAGON: {answer}", "conversation")
        return {"answer": answer, "used_knowledge": bool(context)}
    except FileNotFoundError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
