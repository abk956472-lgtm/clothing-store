import re
import math
from collections import Counter

TOKEN_RE = re.compile(r"[\w\u0600-\u06FF]+", re.UNICODE)

def tokenize(text):
    return TOKEN_RE.findall(text.lower())

def vectorize(text):
    counts = Counter(tokenize(text))
    norm = math.sqrt(sum(v*v for v in counts.values())) or 1.0
    return {k: v/norm for k,v in counts.items()}

def cosine(a,b):
    if not a or not b:
        return 0.0
    return sum(v*b.get(k,0.0) for k,v in a.items())

class Retriever:
    def __init__(self, store):
        self.store = store

    def search(self, query: str, limit: int = 5):
        q = vectorize(query)
        rows = self.store.recent_knowledge(5000)
        scored = [(cosine(q, vectorize(r["content"])), r) for r in rows]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"score": round(s,4), **r} for s,r in scored[:limit] if s > 0]

    def build_context(self, query: str, limit: int = 5):
        hits = self.search(query, limit)
        if not hits:
            return ""
        parts = []
        for h in hits:
            parts.append(f"[Source: {h.get('source','unknown')}]\n{h['content']}")
        return "\n\n".join(parts)
