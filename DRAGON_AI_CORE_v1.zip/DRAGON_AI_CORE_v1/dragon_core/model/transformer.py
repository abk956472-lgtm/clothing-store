import math
import torch
from torch import nn

class CausalSelfAttention(nn.Module):
    def __init__(self, dim, heads, dropout, max_len):
        super().__init__()
        assert dim % heads == 0
        self.heads = heads
        self.head_dim = dim // heads
        self.qkv = nn.Linear(dim, 3*dim)
        self.proj = nn.Linear(dim, dim)
        self.drop = nn.Dropout(dropout)
        mask = torch.tril(torch.ones(max_len, max_len))
        self.register_buffer("mask", mask.view(1,1,max_len,max_len))

    def forward(self, x):
        b,t,c = x.shape
        q,k,v = self.qkv(x).chunk(3, dim=-1)
        q = q.view(b,t,self.heads,self.head_dim).transpose(1,2)
        k = k.view(b,t,self.heads,self.head_dim).transpose(1,2)
        v = v.view(b,t,self.heads,self.head_dim).transpose(1,2)
        att = (q @ k.transpose(-2,-1)) / math.sqrt(self.head_dim)
        att = att.masked_fill(self.mask[:,:,:t,:t] == 0, float("-inf"))
        att = torch.softmax(att, dim=-1)
        att = self.drop(att)
        y = att @ v
        y = y.transpose(1,2).contiguous().view(b,t,c)
        return self.drop(self.proj(y))

class Block(nn.Module):
    def __init__(self, dim, heads, dropout, max_len):
        super().__init__()
        self.ln1 = nn.LayerNorm(dim)
        self.attn = CausalSelfAttention(dim, heads, dropout, max_len)
        self.ln2 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(
            nn.Linear(dim, 4*dim),
            nn.GELU(),
            nn.Linear(4*dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        x = x + self.ff(self.ln2(x))
        return x

class DragonTransformer(nn.Module):
    def __init__(self, vocab_size, dim=192, heads=6, layers=4, max_len=256, dropout=0.1):
        super().__init__()
        self.max_len = max_len
        self.tok = nn.Embedding(vocab_size, dim)
        self.pos = nn.Embedding(max_len, dim)
        self.blocks = nn.ModuleList([
            Block(dim, heads, dropout, max_len) for _ in range(layers)
        ])
        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.head.weight = self.tok.weight

    def forward(self, idx, targets=None):
        b,t = idx.shape
        if t > self.max_len:
            idx = idx[:, -self.max_len:]
            t = idx.shape[1]
        pos = torch.arange(t, device=idx.device).unsqueeze(0)
        x = self.tok(idx) + self.pos(pos)
        for block in self.blocks:
            x = block(x)
        logits = self.head(self.ln(x))
        loss = None
        if targets is not None:
            targets = targets[:, -t:]
            loss = nn.functional.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                targets.reshape(-1),
                ignore_index=-100
            )
        return logits, loss

    @torch.no_grad()
    def generate(self, idx, max_new_tokens=120, temperature=0.8, top_k=40, eos_id=None):
        self.eval()
        for _ in range(max_new_tokens):
            x = idx[:, -self.max_len:]
            logits,_ = self(x)
            logits = logits[:,-1,:] / max(temperature, 1e-5)
            if top_k:
                vals, inds = torch.topk(logits, min(top_k, logits.size(-1)))
                filt = torch.full_like(logits, float("-inf"))
                filt.scatter_(1, inds, vals)
                logits = filt
            probs = torch.softmax(logits, dim=-1)
            nxt = torch.multinomial(probs, 1)
            idx = torch.cat([idx,nxt], dim=1)
            if eos_id is not None and int(nxt.item()) == eos_id:
                break
        return idx
