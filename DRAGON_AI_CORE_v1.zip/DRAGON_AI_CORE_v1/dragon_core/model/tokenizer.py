import json
from pathlib import Path

class CharTokenizer:
    """
    Simple Unicode character tokenizer.
    It is intentionally transparent and can represent Arabic without an external tokenizer.
    """
    def __init__(self, chars=None):
        special = ["<pad>", "<unk>", "<bos>", "<eos>"]
        chars = chars or []
        self.itos = special + sorted(set(chars) - set(special))
        self.stoi = {s:i for i,s in enumerate(self.itos)}

    @property
    def vocab_size(self):
        return len(self.itos)

    @property
    def pad_id(self): return self.stoi["<pad>"]
    @property
    def unk_id(self): return self.stoi["<unk>"]
    @property
    def bos_id(self): return self.stoi["<bos>"]
    @property
    def eos_id(self): return self.stoi["<eos>"]

    def encode(self, text, add_special=True):
        ids = [self.stoi.get(ch, self.unk_id) for ch in text]
        if add_special:
            return [self.bos_id] + ids + [self.eos_id]
        return ids

    def decode(self, ids):
        skip = {self.pad_id, self.bos_id, self.eos_id}
        return "".join(self.itos[i] for i in ids if i not in skip)

    def save(self, path: Path):
        path.write_text(json.dumps({"itos": self.itos}, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: Path):
        obj = json.loads(path.read_text(encoding="utf-8"))
        return cls(obj["itos"][4:])
