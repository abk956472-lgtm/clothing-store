from pathlib import Path
import torch
from .tokenizer import CharTokenizer
from .transformer import DragonTransformer

class ModelEngine:
    def __init__(self, checkpoint: Path, device=None):
        self.checkpoint = Path(checkpoint)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        self.tokenizer = None
        self.loaded = False

    def load(self):
        if not self.checkpoint.exists():
            raise FileNotFoundError(
                f"No checkpoint at {self.checkpoint}. Train the model first."
            )
        ckpt = torch.load(self.checkpoint, map_location=self.device)
        self.tokenizer = CharTokenizer(ckpt["itos"][4:])
        cfg = ckpt["config"]
        self.model = DragonTransformer(
            self.tokenizer.vocab_size,
            dim=cfg["dim"], heads=cfg["heads"], layers=cfg["layers"],
            max_len=cfg["max_len"], dropout=cfg["dropout"]
        ).to(self.device)
        self.model.load_state_dict(ckpt["model"])
        self.model.eval()
        self.loaded = True
        return self

    def generate(self, prompt, max_new_tokens=120, temperature=0.8, top_k=40):
        if not self.loaded:
            self.load()
        ids = self.tokenizer.encode(prompt, add_special=True)
        x = torch.tensor([ids], dtype=torch.long, device=self.device)
        out = self.model.generate(
            x, max_new_tokens=max_new_tokens,
            temperature=temperature, top_k=top_k,
            eos_id=self.tokenizer.eos_id
        )
        decoded = self.tokenizer.decode(out[0].tolist())
        return decoded[len(self.tokenizer.decode(ids)):]
