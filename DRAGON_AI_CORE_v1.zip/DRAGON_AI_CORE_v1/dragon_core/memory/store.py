import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

class Store:
    def __init__(self, db_path: Path):
        self.db_path = str(db_path)
        self._init()

    def _connect(self):
        c = sqlite3.connect(self.db_path)
        c.row_factory = sqlite3.Row
        return c

    def _init(self):
        with self._connect() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS memories(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                kind TEXT NOT NULL DEFAULT 'conversation',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS knowledge(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                source TEXT,
                url TEXT,
                confidence REAL NOT NULL DEFAULT 0.5,
                status TEXT NOT NULL DEFAULT 'unverified',
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_memory_created ON memories(created_at);
            CREATE INDEX IF NOT EXISTS idx_knowledge_created ON knowledge(created_at);
            """)

    @staticmethod
    def now():
        return datetime.now(timezone.utc).isoformat()

    def add_memory(self, content: str, kind: str = "conversation") -> int:
        with self._connect() as c:
            cur = c.execute(
                "INSERT INTO memories(content,kind,created_at) VALUES(?,?,?)",
                (content, kind, self.now()),
            )
            return int(cur.lastrowid)

    def recent_memories(self, limit: int = 20):
        with self._connect() as c:
            return [dict(x) for x in c.execute(
                "SELECT * FROM memories ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()]

    def add_knowledge(self, content: str, source: str = "", url: str = "",
                      confidence: float = 0.5, status: str = "unverified") -> int:
        with self._connect() as c:
            cur = c.execute(
                """INSERT INTO knowledge(content,source,url,confidence,status,created_at)
                   VALUES(?,?,?,?,?,?)""",
                (content, source, url, float(confidence), status, self.now()),
            )
            return int(cur.lastrowid)

    def recent_knowledge(self, limit: int = 20):
        with self._connect() as c:
            return [dict(x) for x in c.execute(
                "SELECT * FROM knowledge ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()]
