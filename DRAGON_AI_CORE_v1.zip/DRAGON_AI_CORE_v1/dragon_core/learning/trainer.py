from pathlib import Path
import torch
from torch.utils.data import Dataset, DataLoader
from ..model.tokenizer import CharTokenizer
from ..model.transformer import DragonTransformer
from ..config import MODEL_DIM, N_HEADS, N_LAYERS, MAX_SEQ_LEN, DROPOUT, CHECKPOINT

class TextDataset(Dataset):
    def __init__(self, ids, seq_len):
        self.ids = ids
        self.seq_len = seq_len

    def __len__(self):
        return max(0, len(self.ids) - self.seq_len - 1)

    def __getitem__(self, i):
        x = torch.tensor(self.ids[i:i+self.seq_len], dtype=torch.long)
        y = torch.tensor(self.ids[i+1:i+self.seq_len+1], dtype=torch.long)
        return x,y

def train_text(data_path: Path, epochs=3, batch_size=8, lr=3e-4, seq_len=None):
    text = Path(data_path).read_text(encoding="utf-8")
    if len(text) < 100:
        raise ValueError("Training text is too small. Add more text to data/train.txt.")

    tokenizer = CharTokenizer(list(text))
    ids = tokenizer.encode(text, add_special=False)
    seq_len = min(seq_len or MAX_SEQ_LEN, len(ids)-2)
    ds = TextDataset(ids, seq_len)
    if len(ds) == 0:
        raise ValueError("Not enough training text for the selected sequence length.")

    loader = DataLoader(ds, batch_size=batch_size, shuffle=True, drop_last=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = DragonTransformer(
        tokenizer.vocab_size, MODEL_DIM, N_HEADS, N_LAYERS,
        seq_len, DROPOUT
    ).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.1)

    model.train()
    for epoch in range(epochs):
        total = 0.0
        for x,y in loader:
            x,y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            _,loss = model(x,y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            total += float(loss.item())
        print(f"epoch={epoch+1}/{epochs} loss={total/max(1,len(loader)):.4f}")

    CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model": model.state_dict(),
        "itos": tokenizer.itos,
        "config": {
            "dim": MODEL_DIM, "heads": N_HEADS, "layers": N_LAYERS,
            "max_len": seq_len, "dropout": DROPOUT
        }
    }, CHECKPOINT)
    print(f"saved: {CHECKPOINT}")
