from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.getenv("DRAGON_DATA_DIR", ROOT / "data"))
DB_PATH = Path(os.getenv("DRAGON_DB_PATH", DATA_DIR / "dragon.db"))
CHECKPOINT = Path(os.getenv("DRAGON_CHECKPOINT", DATA_DIR / "checkpoints" / "dragon_v1.pt"))

MODEL_DIM = int(os.getenv("DRAGON_MODEL_DIM", "192"))
N_HEADS = int(os.getenv("DRAGON_N_HEADS", "6"))
N_LAYERS = int(os.getenv("DRAGON_N_LAYERS", "4"))
MAX_SEQ_LEN = int(os.getenv("DRAGON_MAX_SEQ_LEN", "256"))
DROPOUT = float(os.getenv("DRAGON_DROPOUT", "0.1"))

DATA_DIR.mkdir(parents=True, exist_ok=True)
CHECKPOINT.parent.mkdir(parents=True, exist_ok=True)
