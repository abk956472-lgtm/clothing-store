from urllib.request import Request, urlopen
from urllib.parse import urlparse
import re

def fetch_url(url: str, timeout: int = 15) -> str:
    p = urlparse(url)
    if p.scheme not in ("http","https") or not p.netloc:
        raise ValueError("Only http/https URLs are allowed.")
    req = Request(url, headers={"User-Agent": "DRAGON-AI-Core/1.0"})
    with urlopen(req, timeout=timeout) as r:
        raw = r.read(2_000_000)
        charset = r.headers.get_content_charset() or "utf-8"
    text = raw.decode(charset, errors="replace")
    text = re.sub(r"<script\b[^>]*>.*?</script>", " ", text, flags=re.I|re.S)
    text = re.sub(r"<style\b[^>]*>.*?</style>", " ", text, flags=re.I|re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text
