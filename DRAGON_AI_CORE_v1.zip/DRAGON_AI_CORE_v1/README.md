# DRAGON AI CORE v1

A private, local-first AI core. It does **not** require OpenAI, Google, Anthropic, or another hosted model API.

Important: v1 contains a real small Transformer language-model implementation, tokenizer, training loop, persistent SQLite memory/knowledge, retrieval, RAG context construction, URL ingestion, and a FastAPI server. The model weights start random until you train them on your own dataset.

## Architecture

- `dragon_core/model/` — tokenizer + Transformer model + checkpoint loading
- `dragon_core/memory/` — SQLite memory and knowledge store
- `dragon_core/rag/` — local vector-style retrieval using hashed bag-of-words embeddings
- `dragon_core/learning/` — dataset preparation and model training
- `dragon_core/internet/` — URL fetch and text extraction
- `dragon_core/api/` — local FastAPI server
- `scripts/` — training and ingestion commands

## Requirements

Python 3.10+.

Install:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

## 1. Train the private model

Put your training text in:

`data/train.txt`

Then:

```bash
python scripts/train.py --data data/train.txt --epochs 3
```

The checkpoint is written to:

`data/checkpoints/dragon_v1.pt`

For Android, training a Transformer locally may be very slow. A PC/GPU is recommended.

## 2. Start the core

```bash
python scripts/run_server.py
```

The local API starts at:

`http://127.0.0.1:8000`

Endpoints:

- `GET /health`
- `POST /chat`
- `POST /memory`
- `POST /knowledge`
- `POST /ingest-url`
- `POST /retrieve`

Example:

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d "{\"message\":\"مرحبا\"}"
```

## 3. Connect your own frontend

Your browser UI should call your local/server API, not a third-party model API.

Example:

```javascript
fetch("http://127.0.0.1:8000/chat", {
  method: "POST",
  headers: {"Content-Type": "application/json"},
  body: JSON.stringify({message: "مرحبا DRAGON"})
})
```

## What "learning" means in v1

There are two separate mechanisms:

1. **Knowledge learning**: documents/URLs can be ingested into SQLite and retrieved later.
2. **Model training**: the Transformer weights can be trained on your dataset with `scripts/train.py`.

The core does not silently rewrite its own production code or model weights after every web request. Training is an explicit operation.

## No external AI API

There is no OpenAI API key, Google API key, Claude key, or hosted-model dependency in this project.

The only network feature in v1 is explicit URL ingestion requested through `/ingest-url`.

## Security

Keep the server bound to `127.0.0.1` for local testing. If you expose it to the internet, put it behind authentication/TLS and a reverse proxy before allowing remote access.
