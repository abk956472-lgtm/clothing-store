from abc import ABC, abstractmethod
import httpx
from ..core.config import get_settings

class AIProvider(ABC):
    @abstractmethod
    async def chat(self, messages: list[dict], model: str) -> str: ...

    @abstractmethod
    async def embed(self, text: str, model: str) -> list[float]: ...

class OpenAICompatibleProvider(AIProvider):
    def __init__(self, base_url: str, api_key: str | None):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def headers(self):
        return {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}

    async def chat(self, messages, model):
        async with httpx.AsyncClient(timeout=90) as client:
            r = await client.post(
                f"{self.base_url}/chat/completions",
                headers=self.headers(),
                json={"model": model, "messages": messages, "temperature": 0.2},
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]

    async def embed(self, text, model):
        async with httpx.AsyncClient(timeout=90) as client:
            r = await client.post(
                f"{self.base_url}/embeddings",
                headers=self.headers(),
                json={"model": model, "input": text},
            )
            r.raise_for_status()
            return r.json()["data"][0]["embedding"]

class OllamaProvider(OpenAICompatibleProvider):
    def __init__(self, base_url):
        super().__init__(base_url, None)

def get_ai_provider() -> AIProvider:
    s = get_settings()
    if s.ai_provider == "ollama":
        return OllamaProvider(s.ai_base_url)
    if s.ai_provider == "openai_compatible":
        return OpenAICompatibleProvider(s.ai_base_url, s.ai_api_key)
    raise ValueError(f"Unsupported AI_PROVIDER: {s.ai_provider}")

def get_embedding_provider() -> AIProvider:
    s = get_settings()
    if s.embedding_provider == "ollama":
        return OllamaProvider(s.embedding_base_url)
    if s.embedding_provider == "openai_compatible":
        return OpenAICompatibleProvider(s.embedding_base_url, s.embedding_api_key)
    raise ValueError(f"Unsupported EMBEDDING_PROVIDER: {s.embedding_provider}")
