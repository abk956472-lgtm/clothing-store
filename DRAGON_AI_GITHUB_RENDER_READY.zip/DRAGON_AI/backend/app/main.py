from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from .core.config import get_settings
from .db.session import init_db, SessionLocal
from .db.models import User
from .security.auth import hash_password
from .api import auth, chat, tools, learning, dashboard, feedback

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    async with SessionLocal() as db:
        result = await db.execute(select(User).where(User.username == get_settings().owner_username))
        owner = result.scalar_one_or_none()
        if not owner:
            owner = User(
                username=get_settings().owner_username,
                password_hash=hash_password(get_settings().owner_password),
                role="OWNER",
            )
            db.add(owner)
            await db.commit()
    yield

settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)
app.include_router(auth.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(tools.router, prefix="/api")
app.include_router(learning.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(feedback.router, prefix="/api")

@app.get("/api/health")
async def health():
    return {"status": "ok", "name": settings.app_name}

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
