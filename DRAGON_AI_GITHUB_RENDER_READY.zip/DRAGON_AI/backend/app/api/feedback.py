from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.session import get_db
from ..db.models import Feedback, Message
from ..security.auth import current_user

router = APIRouter(prefix="/feedback", tags=["feedback"])

class FeedbackRequest(BaseModel):
    message_id: UUID
    kind: str = Field(pattern="^(GOOD|BAD|CORRECTION)$")
    correction: str | None = Field(default=None, max_length=10000)

@router.post("")
async def feedback(req: FeedbackRequest, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    if req.kind == "CORRECTION" and not req.correction:
        raise HTTPException(400, "correction is required for CORRECTION feedback")
    if not await db.get(Message, req.message_id):
        raise HTTPException(404, "message not found")
    item = Feedback(user_id=user.id, message_id=req.message_id, kind=req.kind, correction=req.correction)
    db.add(item)
    await db.commit()
    return {"ok": True}
