from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.session import get_db
from ..security.auth import current_user
from ..tools.manager import tool_manager

router = APIRouter(prefix="/tools", tags=["tools"])

class ToolRequest(BaseModel):
    tool: str
    query: str = Field(min_length=1, max_length=5000)

@router.post("/execute")
async def execute(req: ToolRequest, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    try:
        if req.tool == "web_search":
            return {"results": await tool_manager.execute(req.tool, user, db, query=req.query)}
        if req.tool == "web_reader":
            return await tool_manager.execute(req.tool, user, db, url=req.query)
        raise HTTPException(400, "Unsupported tool")
    except PermissionError as e:
        raise HTTPException(403, str(e))
    except RuntimeError as e:
        raise HTTPException(503, str(e))
