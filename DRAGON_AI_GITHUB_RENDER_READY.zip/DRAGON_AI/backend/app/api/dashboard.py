from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.session import get_db
from ..db.models import Knowledge, Memory, Message, ToolAudit
from ..security.auth import current_user
from ..core.config import get_settings

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@router.get("")
async def dashboard(db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    counts = {}
    for name, model in [("knowledge", Knowledge), ("memory", Memory), ("messages", Message), ("tool_audit", ToolAudit)]:
        counts[name] = (await db.execute(select(func.count()).select_from(model))).scalar_one()
    s = get_settings()
    return {
        "status": "online",
        "model": s.ai_model,
        "provider": s.ai_provider,
        "owner_mode": user.role == "OWNER",
        "counts": counts,
        "web_search_configured": bool(s.brave_search_api_key),
        "vector_db": s.qdrant_url,
    }
