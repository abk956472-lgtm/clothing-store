from uuid import UUID
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.session import get_db
from ..security.auth import current_user
from ..services.chat import answer

router = APIRouter(prefix="/chat", tags=["chat"])

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=20000)
    conversation_id: UUID | None = None

@router.post("")
async def chat(req: ChatRequest, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    conversation, message = await answer(db, user, req.conversation_id, req.message)
    return {
        "conversation_id": str(conversation.id),
        "message_id": str(message.id),
        "answer": message.content,
    }
