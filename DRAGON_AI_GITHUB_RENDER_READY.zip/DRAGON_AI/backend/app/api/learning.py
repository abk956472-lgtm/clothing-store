from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.session import get_db
from ..security.auth import require_role
from ..services.learning import learn_from_web

router = APIRouter(prefix="/learning", tags=["learning"])

class LearnRequest(BaseModel):
    query: str = Field(min_length=2, max_length=1000)

@router.post("/web")
async def learn(req: LearnRequest, db: AsyncSession = Depends(get_db), user=Depends(require_role("OWNER", "ADMIN"))):
    try:
        return await learn_from_web(req.query, db)
    except RuntimeError as e:
        raise HTTPException(503, str(e))
