from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..ai.providers import get_embedding_provider
from ..core.config import get_settings
from ..db.models import Knowledge
from .vector_store import vector_store

async def retrieve_knowledge(query: str, db: AsyncSession, limit: int | None = None):
    s = get_settings()
    limit = limit or s.max_rag_results
    embedding = await get_embedding_provider().embed(query, s.embedding_model)
    await vector_store.ensure(len(embedding))
    hits = await vector_store.search(embedding, limit)
    ids = [h.id for h in hits.points]
    if not ids:
        return []
    result = await db.execute(select(Knowledge).where(Knowledge.id.in_(ids)))
    by_id = {str(k.id): k for k in result.scalars()}
    return [by_id[str(h.id)] for h in hits.points if str(h.id) in by_id]

async def index_knowledge(item: Knowledge):
    s = get_settings()
    embedding = await get_embedding_provider().embed(item.content, s.embedding_model)
    await vector_store.ensure(len(embedding))
    await vector_store.upsert(str(item.id), embedding, {
        "knowledge_id": str(item.id),
        "source_url": item.source_url,
        "topic": item.topic,
        "verification_status": item.verification_status,
    })
