from qdrant_client import AsyncQdrantClient, models
from ..core.config import get_settings

class VectorStore:
    def __init__(self):
        s = get_settings()
        self.client = AsyncQdrantClient(url=s.qdrant_url)
        self.collection = s.qdrant_collection

    async def ensure(self, vector_size: int):
        collections = await self.client.get_collections()
        if self.collection not in [c.name for c in collections.collections]:
            await self.client.create_collection(
                collection_name=self.collection,
                vectors_config=models.VectorParams(size=vector_size, distance=models.Distance.COSINE),
            )

    async def upsert(self, point_id: str, vector: list[float], payload: dict):
        await self.client.upsert(
            collection_name=self.collection,
            points=[models.PointStruct(id=point_id, vector=vector, payload=payload)],
        )

    async def search(self, vector: list[float], limit: int = 8):
        return await self.client.query_points(
            collection_name=self.collection,
            query=vector,
            limit=limit,
            with_payload=True,
        )

vector_store = VectorStore()
