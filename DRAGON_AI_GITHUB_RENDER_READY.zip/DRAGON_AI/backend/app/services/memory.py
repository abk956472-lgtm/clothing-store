from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.models import Memory

async def recent_memories(db: AsyncSession, user_id, limit=8):
    result = await db.execute(
        select(Memory).where(Memory.user_id == user_id).order_by(Memory.updated_at.desc()).limit(limit)
    )
    return list(result.scalars())

async def add_memory(db: AsyncSession, user_id, kind: str, content: str, source=None, confidence=0.7, metadata=None):
    item = Memory(
        user_id=user_id, kind=kind, content=content, source=source,
        confidence=confidence, metadata_json=metadata or {}
    )
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return item
