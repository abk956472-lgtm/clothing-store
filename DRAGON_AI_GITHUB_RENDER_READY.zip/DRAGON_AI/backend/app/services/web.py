from urllib.parse import urlparse
import httpx
from bs4 import BeautifulSoup
from ..core.config import get_settings

async def search_web(query: str, count: int = 5) -> list[dict]:
    s = get_settings()
    if not s.brave_search_api_key:
        raise RuntimeError("Web search is not configured. Set BRAVE_SEARCH_API_KEY.")
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(
            "https://api.search.brave.com/res/v1/web/search",
            headers={"X-Subscription-Token": s.brave_search_api_key, "Accept": "application/json"},
            params={"q": query, "count": count},
        )
        r.raise_for_status()
        data = r.json()
        return [
            {
                "title": x.get("title"),
                "url": x.get("url"),
                "description": x.get("description"),
                "domain": urlparse(x.get("url", "")).netloc,
            }
            for x in data.get("web", {}).get("results", [])
        ]

async def read_url(url: str) -> dict:
    s = get_settings()
    async with httpx.AsyncClient(timeout=s.web_fetch_timeout, follow_redirects=True,
                                 headers={"User-Agent": "DRAGON-AI/1.0"}) as client:
        r = await client.get(url)
        r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    title = soup.title.get_text(" ", strip=True) if soup.title else url
    text = " ".join(soup.stripped_strings)
    return {"url": str(r.url), "title": title[:500], "text": text[:100000], "domain": urlparse(str(r.url)).netloc}
