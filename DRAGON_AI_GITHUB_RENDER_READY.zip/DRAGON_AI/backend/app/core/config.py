from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "DRAGON AI"
    environment: str = "development"
    host: str = "0.0.0.0"
    port: int = 8000
    database_url: str
    qdrant_url: str = "http://localhost:6333"
    qdrant_collection: str = "dragon_knowledge"
    jwt_secret: str
    access_token_minutes: int = 60
    cors_origins: str = "http://localhost:8000"
    owner_username: str = "ABDO"
    owner_password: str
    ai_provider: str = "ollama"
    ai_model: str = "llama3.1:8b"
    ai_base_url: str = "http://localhost:11434"
    ai_api_key: str | None = None
    brave_search_api_key: str | None = None
    embedding_provider: str = "ollama"
    embedding_model: str = "nomic-embed-text"
    embedding_base_url: str = "http://localhost:11434"
    embedding_api_key: str | None = None
    max_context_memories: int = 8
    max_rag_results: int = 8
    web_fetch_timeout: int = 15
    rate_limit_per_minute: int = 60
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_list(self) -> list[str]:
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

@lru_cache
def get_settings() -> Settings:
    return Settings()
