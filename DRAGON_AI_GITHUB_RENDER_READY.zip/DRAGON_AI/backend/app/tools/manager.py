from dataclasses import dataclass
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.models import User, ToolAudit
from ..services.web import search_web, read_url

@dataclass
class Tool:
    name: str
    permission: str
    handler: object

class ToolManager:
    def __init__(self):
        self.tools = {
            "web_search": Tool("web_search", "tool:web_search", search_web),
            "web_reader": Tool("web_reader", "tool:web_reader", read_url),
        }

    async def execute(self, name: str, user: User, db: AsyncSession, **kwargs):
        tool = self.tools.get(name)
        if not tool:
            raise ValueError("Unknown tool")
        allowed = user.role in {"ADMIN", "OWNER"} or tool.permission in {"tool:web_search", "tool:web_reader"}
        db.add(ToolAudit(user_id=user.id, tool_name=name, allowed=allowed, detail="server-side permission check"))
        await db.commit()
        if not allowed:
            raise PermissionError("Tool permission denied")
        return await tool.handler(**kwargs)

tool_manager = ToolManager()
