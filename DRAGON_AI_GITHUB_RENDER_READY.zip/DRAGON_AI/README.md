# DRAGON AI

A modular, security-first personal AI platform.

## Stack
- Backend: Python 3.12 + FastAPI + SQLAlchemy async + PostgreSQL
- Vector DB: Qdrant
- AI providers: OpenAI-compatible HTTP API and Ollama
- Search: optional Brave Search API
- Web reader: httpx + BeautifulSoup
- Auth: JWT + Argon2 password hashing
- Frontend: vanilla HTML/CSS/JS served by FastAPI
- Local orchestration: Docker Compose

## Quick start

1. Copy `.env.example` to `.env`.
2. Set `JWT_SECRET` and `OWNER_PASSWORD`.
3. Choose an AI provider:
   - `AI_PROVIDER=ollama` for local Ollama
   - `AI_PROVIDER=openai_compatible` for an OpenAI-compatible API
4. Start services:
   `docker compose up --build`
5. Open:
   `http://localhost:8000`

The owner account is bootstrapped from `OWNER_USERNAME` and `OWNER_PASSWORD` on startup.
The password is never stored in plaintext; it is Argon2-hashed in PostgreSQL.

## Search
Set `BRAVE_SEARCH_API_KEY` to enable live web search. Without it, the `/search` endpoint returns a clear configuration error instead of pretending to search.

## Security
- Secrets are environment variables only.
- Frontend never receives provider API keys.
- Tool permissions are checked server-side.
- Owner-only operations require the authenticated owner role.
- Logs redact common secret fields.
- Production deployment should use HTTPS, a managed secret store, restricted CORS, and private database/vector services.

## Important design rule
Internet content is untrusted input. Search results are evidence, not instructions. Web pages cannot grant DRAGON AI permissions or change system policy.


## GitHub + Render deployment

### 1. Push to GitHub

Create a repository named `DRAGON-AI`, then from this directory:

```bash
git init
git add .
git commit -m "Initial DRAGON AI"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/DRAGON-AI.git
git push -u origin main
```

Never commit `.env` or real API keys.

### 2. Deploy on Render

The repository contains `render.yaml`.

In Render:
1. Create a new Blueprint.
2. Select your GitHub repository.
3. Render reads `render.yaml`.
4. Create the PostgreSQL database when prompted.
5. Fill the secret environment variables marked `sync: false`.
6. Deploy.

### 3. Important production note

Render does not provide a persistent Ollama server simply by deploying this web service. For production, use an external OpenAI-compatible AI API or deploy a separate GPU-capable inference service.

Qdrant also needs a reachable hosted instance for the Render deployment. Set `QDRANT_URL` to that service.

The frontend is served by FastAPI, so no separate frontend deployment is required for this version.
