# DRAGON AI architecture

```text
Browser
  |
  v
FastAPI API
  |
  +--> Auth / RBAC / Rate limit
  |
  +--> Conversation Manager
  |      +--> short-term messages
  |      +--> summaries
  |      +--> important facts
  |
  +--> Context Manager
  |      +--> Memory retrieval
  |      +--> RAG retrieval
  |
  +--> AI Engine
  |      +--> provider abstraction
  |      +--> Ollama
  |      +--> OpenAI-compatible providers
  |
  +--> Tool Manager
  |      +--> web search
  |      +--> web reader
  |      +--> future tools
  |
  +--> Learning Engine
  |      SEARCH -> READ -> EXTRACT -> COMPARE -> QUALITY -> STORE -> EMBED
  |
  +--> PostgreSQL
  |      users, conversations, messages, memories, knowledge, sources,
  |      feedback, audits, improvement proposals
  |
  +--> Qdrant
         semantic retrieval vectors
```

The current foundation deliberately does not perform automatic model fine-tuning or production code mutation. Improvements become proposals requiring OWNER approval.
