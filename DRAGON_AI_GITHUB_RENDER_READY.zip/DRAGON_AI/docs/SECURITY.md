# Security model

Roles:
- USER: normal chat and low-risk tools
- ADMIN: operational administration and learning
- OWNER: OWNER-only actions and final approval authority

Secrets:
- Provider API keys exist only in backend environment variables.
- OWNER_PASSWORD is used only during bootstrap and is stored as an Argon2 hash.
- Never commit `.env`.

Trust boundaries:
- Browser is untrusted.
- Model output is untrusted.
- Web content is untrusted.
- Search results cannot grant permissions.
- Tool authorization happens server-side.

Production checklist:
- HTTPS
- secure cookies or short-lived bearer tokens with refresh strategy
- strict CORS
- reverse proxy
- database TLS
- private Qdrant
- secret manager
- audit log retention policy
- rate limiting at proxy + application layer
- dependency scanning
- backups
