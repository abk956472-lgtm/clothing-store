# Database schema

users
- id, username, password_hash, role, is_active, created_at

conversations
- id, user_id, title, summary, created_at, updated_at

messages
- id, conversation_id, role, content, created_at

memories
- id, user_id, kind, content, source, confidence, metadata_json, timestamps

knowledge
- id, content, source, source_url, topic, tags, confidence,
  verification_status, created_at, updated_at, supersedes_id

sources
- id, url, title, domain, quality_score, fetched_at

tool_audit
- id, user_id, tool_name, allowed, detail, created_at

feedback
- id, user_id, message_id, kind, correction, created_at

improvement_proposals
- id, title, rationale, proposed_change, status, created_at
