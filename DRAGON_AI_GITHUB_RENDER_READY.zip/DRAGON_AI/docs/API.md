# API

- `POST /api/auth/token` login
- `GET /api/auth/me` current user
- `POST /api/chat` conversation + RAG answer
- `POST /api/tools/execute` controlled tool execution
- `POST /api/learning/web` OWNER/ADMIN web learning
- `POST /api/feedback` GOOD/BAD/CORRECTION
- `GET /api/dashboard` operational status
- `GET /api/health` health check
- OpenAPI UI: `/docs`
