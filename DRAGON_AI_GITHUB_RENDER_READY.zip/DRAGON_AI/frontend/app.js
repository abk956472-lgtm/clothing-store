let token = localStorage.getItem("dragon_token");
let conversationId = null;

const $ = id => document.getElementById(id);
function add(role,text){ const d=document.createElement("div"); d.className="msg "+role; d.textContent=text; $("messages").appendChild(d); $("messages").scrollTop=$("messages").scrollHeight; }

async function login(){
  if(token) return true;
  const username=prompt("DRAGON AI username", "ABDO");
  const password=prompt("Password");
  if(!username||!password) return false;
  const body=new URLSearchParams({username,password});
  const r=await fetch("/api/auth/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
  if(!r.ok){alert("Login failed");return false}
  const data=await r.json(); token=data.access_token; localStorage.setItem("dragon_token",token); return true;
}

async function api(path, options={}){
  options.headers={...(options.headers||{}),Authorization:"Bearer "+token,"Content-Type":"application/json"};
  const r=await fetch(path,options); if(r.status===401){token=null;localStorage.removeItem("dragon_token")}
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.detail||"Request failed");
  return data;
}

async function refresh(){
  if(!token) return;
  try{$("dashboard").textContent=JSON.stringify(await api("/api/dashboard"),null,2);$("status").textContent="ONLINE"}catch(e){$("status").textContent="AUTH REQUIRED"}
}
$("chatForm").onsubmit=async e=>{
  e.preventDefault();
  if(!await login()) return;
  const text=$("input").value.trim(); $("input").value=""; if(!text)return;
  add("user",text); add("assistant","...");
  try{
    const data=await api("/api/chat",{method:"POST",body:JSON.stringify({message:text,conversation_id:conversationId})});
    conversationId=data.conversation_id; document.querySelectorAll(".assistant").at(-1).textContent=data.answer;
  }catch(e){document.querySelectorAll(".assistant").at(-1).textContent="ERROR: "+e.message}
  refresh();
};
$("searchBtn").onclick=async()=>{
  if(!await login())return;
  try{const q=$("toolInput").value; add("assistant",JSON.stringify(await api("/api/tools/execute",{method:"POST",body:JSON.stringify({tool:"web_search",query:q})}),null,2))}catch(e){add("assistant","ERROR: "+e.message)}
};
$("learnBtn").onclick=async()=>{
  if(!await login())return;
  try{const q=$("toolInput").value; add("assistant",JSON.stringify(await api("/api/learning/web",{method:"POST",body:JSON.stringify({query:q})}),null,2))}catch(e){add("assistant","ERROR: "+e.message)}
};
refresh();
